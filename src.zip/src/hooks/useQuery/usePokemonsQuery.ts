"use client";

import { getPokemons } from "@/api/pokemon.api";
import { TPokemon } from "@/types/pokemons.type";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";

export default function usePokemonsQuery() {}
