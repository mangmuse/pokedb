import PokemonList from "@/components/PokemonList";

export default function Home() {
  return (
    <section className="">
      <h1>포켓몬 도감</h1>
      <PokemonList />
    </section>
  );
}
