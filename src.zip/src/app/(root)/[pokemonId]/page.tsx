import { TPokemon } from "@/types/pokemons.type";
import axios from "axios";

interface PokemonDetailPageProps {
  params: {
    pokemonId: string;
  };
}
const getPokemonData = async (pokemonId: string): Promise<TPokemon> => {
  const { data } = await axios.get<TPokemon>(
    `http://localhost:3001/api/pokemons/${pokemonId}`,
    { params: { pokemonId } }
  );
  return data;
};

export default async function PokemonDetailPage({
  params: { pokemonId },
}: PokemonDetailPageProps) {
  //   const pokemonRes = await axios.get<TPokemon>(
  //     `http://localhost:3001/api/pokemons/${pokemonId}`,
  //     { params: { pokemonId: pokemonId.toString() } }
  //   );
  //   const pokemon = pokemonRes.data;
  const pokemon = await getPokemonData(pokemonId);

  return <>ㅁㄴㅇ</>;
}
